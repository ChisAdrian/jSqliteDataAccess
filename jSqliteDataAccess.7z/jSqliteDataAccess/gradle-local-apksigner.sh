export PATH=/Portables/Laz4Android/sdk/platform-tools:$PATH
export PATH=/Portables/Laz4Android/sdk/build-tools/30.0.2:$PATH
export GRADLE_HOME=/Portables/Laz4Android/gradle-6.6.1
export PATH=$PATH:$GRADLE_HOME/bin
zipalign -v -p 4 /Portables/Laz4Android/Projects/AppLAMWProject_x/build/outputs/apk/release/AppLAMWProject_x-armeabi-v7a-release-unsigned.apk /Portables/Laz4Android/Projects/AppLAMWProject_x/build/outputs/apk/release/AppLAMWProject_x-armeabi-v7a-release-unsigned-aligned.apk
apksigner sign --ks /Portables/Laz4Android/Projects/AppLAMWProject_x/applamwproject_x-release.keystore --ks-pass pass:123456 --key-pass pass:123456 --out /Portables/Laz4Android/Projects/AppLAMWProject_x/build/outputs/apk/release/AppLAMWProject_x-release.apk /Portables/Laz4Android/Projects/AppLAMWProject_x/build/outputs/apk/release/AppLAMWProject_x-armeabi-v7a-release-unsigned-aligned.apk
