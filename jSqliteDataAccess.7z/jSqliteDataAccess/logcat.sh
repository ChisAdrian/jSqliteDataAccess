/Portables/Laz4Android/sdk/platform-tools/adb logcat &
