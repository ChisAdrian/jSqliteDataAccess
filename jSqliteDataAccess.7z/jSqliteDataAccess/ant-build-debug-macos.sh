export PATH=/Portables/Laz4Android/apache-ant-1.10.12/bin:$PATH
export JAVA_HOME=${/usr/libexec/java_home}
export PATH=${JAVA_HOME}/bin:$PATH
cd /Portables/Laz4Android/Projects/AppLAMWProject_x
ant -Dtouchtest.enabled=true debug
