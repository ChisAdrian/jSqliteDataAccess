export JAVA_HOME=${/usr/libexec/java_home}
export PATH=${JAVA_HOME}/bin:$PATH
cd /Portables/Laz4Android/Projects/AppLAMWProject_x
jarsigner -verify -verbose -certs /Portables/Laz4Android/Projects/AppLAMWProject_x/bin/AppLAMWProject_x-release.apk
