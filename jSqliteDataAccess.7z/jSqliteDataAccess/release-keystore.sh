export JAVA_HOME=/Portables/Laz4Android/openlogic-openjdk-8u262-b10-win-64
cd /Portables/Laz4Android/Projects/AppLAMWProject_x
LC_ALL=C keytool -genkey -v -keystore applamwproject_x-release.keystore -alias applamwproject_x.keyalias -keyalg RSA -keysize 2048 -validity 10000 < /Portables/Laz4Android/Projects/AppLAMWProject_x/keytool_input.txt
