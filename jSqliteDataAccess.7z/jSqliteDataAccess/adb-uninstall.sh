/Portables/Laz4Android/sdk/platform-tools/adb uninstall org.lamw.applamwproject_x
