export JAVA_HOME=/Portables/Laz4Android/openlogic-openjdk-8u262-b10-win-64
cd /Portables/Laz4Android/Projects/AppLAMWProject_x
jarsigner -verify -verbose -certs /Portables/Laz4Android/Projects/AppLAMWProject_x/build/outputs/apk/release/AppLAMWProject_x-release.apk
