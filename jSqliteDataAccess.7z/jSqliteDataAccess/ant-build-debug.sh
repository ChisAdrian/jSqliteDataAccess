export PATH=/Portables/Laz4Android/apache-ant-1.10.12/bin:$PATH
export JAVA_HOME=/Portables/Laz4Android/openlogic-openjdk-8u262-b10-win-64
cd /Portables/Laz4Android/Projects/AppLAMWProject_x
ant -Dtouchtest.enabled=true debug
