export JAVA_HOME=${/usr/libexec/java_home}
export PATH=${JAVA_HOME}/bin:$PATH
cd /Portables/Laz4Android/Projects/AppLAMWProject_x
keytool -genkey -v -keystore applamwproject_x-release.keystore -alias applamwproject_x.keyalias -keyalg RSA -keysize 2048 -validity 10000 < /Portables/Laz4Android/Projects/AppLAMWProject_x/keytool_input.txt
