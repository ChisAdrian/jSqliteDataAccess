export PATH=/Portables/Laz4Android/sdk/platform-tools:$PATH
export GRADLE_HOME=/Portables/Laz4Android/gradle-6.6.1/
export PATH=$PATH:$GRADLE_HOME/bin
source ~/.bashrc
gradle clean bundle --info
