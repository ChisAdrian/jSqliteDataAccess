/Portables/Laz4Android/sdk/platform-tools/adb uninstall org.lamw.applamwproject_x
/Portables/Laz4Android/sdk/platform-tools/adb install -r /Portables/Laz4Android/Projects/AppLAMWProject_x/build/outputs/apk/debug/AppLAMWProject_x-armeabi-v7a-debug.apk
